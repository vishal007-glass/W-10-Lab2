const SECRET = "my-secret-key";
const MONGO_URI = "mongodb://localhost:27017/fullstack-course";

module.exports = { SECRET,MONGO_URI, };